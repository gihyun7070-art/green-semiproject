import React from "react";

const AddPage = () => {
  return <div className="text-3xl font-extrabold">AddPage</div>;
};

export default AddPage;
