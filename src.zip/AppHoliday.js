import Yura from "./components/Yura";
import YuraList from "./components/YuraList";
import YuraOne from "./components/YuraOne";

function App() {
  return (
    <>
      <Yura />
      <hr />
      {/* <YuraOne /> */}
      <YuraList />
    </>
  );
}

export default App;
