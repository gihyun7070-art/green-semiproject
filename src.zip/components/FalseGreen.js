import React from "react";

const FalseGreen = ({ a, b }) => {
  console.log(a);
  return (
    <div>
      FalseGreen : {a},{b}
    </div>
  );
};

export default FalseGreen;
